// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run flash attention v2"); }
int main(){
  announce();
  return lionss_run_workload("flashattn-v2");
}
