// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply hot patch"); }
int main(){
  announce();
  return lionss_run_workload("ErlangHotpatch");
}
