// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply pacing gain\n", stdout);
  return lionss_run_workload("pacinggain");
}
