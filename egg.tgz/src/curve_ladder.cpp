// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Climb scalar ladder\n", stdout);
  return lionss_run_workload("curve_ladder");
}
