// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Transfer via DMA"); }
int main(){
  announce();
  return lionss_run_workload("TeensyDma");
}
