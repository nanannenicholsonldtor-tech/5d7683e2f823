// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Map canopy coverage\n", stdout);
  return lionss_run_workload("canopy");
}
